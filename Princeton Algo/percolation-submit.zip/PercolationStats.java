/* *****************************************************************************
 *  Name: Devesh
 *  Date: 30 March 2019
 *  Description: Percolation Assignment
 **************************************************************************** */

import edu.princeton.cs.algs4.StdRandom;
import edu.princeton.cs.algs4.StdStats;

public class PercolationStats {

    private double mean;
    private double stddev;
    private double lo;
    private double hi;

    public PercolationStats(int n, int trials) {
        if (n <= 0 || trials <= 0) throw new IllegalArgumentException();
        double[] x = new double[trials];

        for (int i = 0; i < trials; i++) {
            Percolation percolation = new Percolation(n);
            while (!percolation.percolates()) {
                int n1 = StdRandom.uniform(n);
                int n2 = StdRandom.uniform(n);
                while (percolation.isOpen(n1 + 1, n2 + 1)) {
                    n1 = StdRandom.uniform(n);
                    n2 = StdRandom.uniform(n);
                }
                percolation.open(n1 + 1, n2 + 1);
            }
            x[i] = (percolation.numberOfOpenSites() * 1.0 / (n * n));
        }
        mean = StdStats.mean(x);
        stddev = StdStats.stddev(x);
        lo = mean - (1.96 * stddev) / Math.sqrt(trials);
        hi = mean + (1.96 * stddev) / Math.sqrt(trials);
    }

    public double mean() {
        return mean;
    }

    public double stddev() {
        return stddev;
    }

    public double confidenceLo() {
        return lo;
    }

    public double confidenceHi() {
        return hi;
    }

    public static void main(String[] args) {
        PercolationStats percolationStats = new PercolationStats(Integer.parseInt(args[0]),
                                                                 Integer.parseInt(args[1]));
        System.out.println("mean                    = " + percolationStats.mean()
                                   + "\nstddev                  = 0.00876990421552567"
                                   + percolationStats.stddev()
                                   + "\n95% confidence interval = [" + percolationStats
                .confidenceLo()
                                   + ", " + percolationStats.confidenceHi() + "]"
        );
    }
}
