/* *****************************************************************************
 *  Name: Devesh
 *  Date: 30 March 2019
 *  Description: Percolation Assignment
 **************************************************************************** */

import edu.princeton.cs.algs4.WeightedQuickUnionUF;

public class Percolation {
    private boolean[][] grid;
    private int n;
    private int numberOfOpenSites;
    private WeightedQuickUnionUF uf;
    private WeightedQuickUnionUF temp;
    private final int[] dx = { -1, 1, 0, 0 };
    private final int[] dy = { 0, 0, 1, -1 };

    public Percolation(int n) {
        if (n <= 0) throw new java.lang.IllegalArgumentException();
        grid = new boolean[n][n];
        uf = new WeightedQuickUnionUF(n * n + 2);
        temp = new WeightedQuickUnionUF(n * n + 1);
        this.n = n;
    }

    public void open(int row, int col) {
        if (!isValid(row - 1, col - 1)) throw new IllegalArgumentException();
        int i = row - 1, j = col - 1;
        if (!grid[i][j]) {
            grid[i][j] = true;
            numberOfOpenSites++;
            if (i == 0) {
                uf.union(0, toUF(row, col));
                temp.union(0, toUF(row, col));
            }
            if (i == n - 1) uf.union(n * n + 1, toUF(row, col));
            for (int counter = 0; counter < 4; counter++) {
                int i1 = i + dx[counter], j1 = j + dy[counter];
                if (isValid(i1, j1) && grid[i1][j1]) {
                    uf.union(toUF(i1 + 1, j1 + 1), toUF(i + 1, j + 1));
                    temp.union(toUF(i1 + 1, j1 + 1), toUF(i + 1, j + 1));
                }
            }
        }
    }

    public boolean isOpen(int row, int col) {
        if (!isValid(row - 1, col - 1)) throw new IllegalArgumentException();
        return grid[row - 1][col - 1];
    }

    public boolean isFull(int row, int col) {
        if (!isValid(row - 1, col - 1)) throw new IllegalArgumentException();
        return temp.connected(toUF(row, col), 0);
    }

    public int numberOfOpenSites() {
        return numberOfOpenSites;
    }

    public boolean percolates() {
        return uf.connected(0, n * n + 1);
    }

    private int toUF(int row, int col) {
        return n * (row - 1) + col;
    }

    private boolean isValid(int i, int j) {
        return (i >= 0 && j >= 0 && i < n && j < n);
    }
}
